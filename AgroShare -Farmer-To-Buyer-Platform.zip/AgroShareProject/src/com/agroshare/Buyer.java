package com.agroshare;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Buyer {

    public void registerBuyer() {

        try {

            Scanner sc = new Scanner(System.in);
            sc.close();

            System.out.println("Enter buyer name");
            String name = sc.nextLine();

            System.out.println("Enter mobile");
            String mobile = sc.nextLine();

            Connection con = DBConnection.getConnection();

            String sql = "insert into buyer(name,mobile) values(?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, name);
            ps.setString(2, mobile);

            ps.executeUpdate();

            System.out.println("Buyer Registered");

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}