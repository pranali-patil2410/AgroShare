package com.agroshare;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Product {

    public void addProduct() {

        try {

            Scanner sc = new Scanner(System.in);
            sc.close();

            System.out.println("Enter product name");
            String name = sc.nextLine();

            System.out.println("Enter price");
            double price = sc.nextDouble();

            System.out.println("Enter farmer id");
            int fid = sc.nextInt();

            Connection con = DBConnection.getConnection();

            String sql = "insert into product(name,price,farmer_id) values(?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, name);
            ps.setDouble(2, price);
            ps.setInt(3, fid);

            ps.executeUpdate();

            System.out.println("Product Added");

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}