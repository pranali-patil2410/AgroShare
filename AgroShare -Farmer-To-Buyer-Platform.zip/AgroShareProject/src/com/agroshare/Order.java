package com.agroshare;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Order {

    public void placeOrder() {

        try {

            Scanner sc = new Scanner(System.in);
            sc.close();

            System.out.println("Enter product id");
            int pid = sc.nextInt();

            System.out.println("Enter buyer id");
            int bid = sc.nextInt();

            System.out.println("Enter quantity");
            int qty = sc.nextInt();

            Connection con = DBConnection.getConnection();

            String sql = "insert into orders(product_id,buyer_id,quantity) values(?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, pid);
            ps.setInt(2, bid);
            ps.setInt(3, qty);

            ps.executeUpdate();

            System.out.println("Order Placed Successfully");

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
