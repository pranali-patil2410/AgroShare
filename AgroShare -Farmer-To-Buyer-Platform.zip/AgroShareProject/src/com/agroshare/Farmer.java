package com.agroshare;

import java.sql.Connection;
import java.util.Scanner;
import java.sql.PreparedStatement;

public class Farmer {

    public void registerFarmer() {

        try {

            Scanner sc = new Scanner(System.in);
            sc.close();

            System.out.println("Enter farmer name");
            String name = sc.nextLine();

            System.out.println("Enter mobile");
            String mobile = sc.nextLine();

            System.out.println("Enter address");
            String address = sc.nextLine();

            Connection con = DBConnection.getConnection();

            String sql = "insert into farmer(name,mobile,address) values(?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, name);
            ps.setString(2, mobile);
            ps.setString(3, address);

            ps.executeUpdate();

            System.out.println("Farmer Registered Successfully");

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}