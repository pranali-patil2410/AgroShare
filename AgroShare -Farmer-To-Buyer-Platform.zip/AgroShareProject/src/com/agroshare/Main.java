package com.agroshare;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
   

        Farmer f = new Farmer();
        Buyer b = new Buyer();
        Product p = new Product();
        Order o = new Order();

        while (true) {

            System.out.println("1 Register Farmer");
            System.out.println("2 Register Buyer");
            System.out.println("3 Add Product");
            System.out.println("4 Place Order");
            System.out.println("5 Exit");
            
            while(!sc.hasNextInt()) {
            	String invalid=sc.next();
            	System.out.println(" ' "+invalid+" ' is not a number. try again (1-5):");
            }

            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {

                case 1:
                    f.registerFarmer();
                    break;

                case 2:
                    b.registerBuyer();
                    break;

                case 3:
                    p.addProduct();
                    break;

                case 4:
                    o.placeOrder();
                    break;

                case 5:
                    System.exit(0);

                default:
                    System.out.println("Invalid Choice");
                    sc.close();
            }
        }
    }
}