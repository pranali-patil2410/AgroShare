/**
 * 
 */
/**
 * 
 */
module AgroShareProject {
	requires java.sql;
}